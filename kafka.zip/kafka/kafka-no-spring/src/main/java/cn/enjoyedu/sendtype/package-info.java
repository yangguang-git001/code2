/**
 * @author King老师   享学课堂 https://enjoy.ke.qq.com
 * 类说明：消息的发送模式
 */
package cn.enjoyedu.sendtype;
